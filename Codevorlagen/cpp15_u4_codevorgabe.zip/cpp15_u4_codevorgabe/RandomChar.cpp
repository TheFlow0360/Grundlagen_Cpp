#include "RandomChar.h"

int const m_Length = 71;
char const m_AllPossibleChars[m_Length] = { "01234567890abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ!�$%&?@" };

RandomChar::RandomChar()
{
}

RandomChar::~RandomChar()
{
}