#include "timer.hpp"
#include <iostream>

// TODO: Definition of constructor and destructor of the ScopeTimer.