#include "node.hpp"

// TODO: streaming operator implementation