1. Kommentiere zun�chst die Policy - Registration aus
2. Implementiere das Singleton Zugriffsmuster
  - gebe write eine leere Implementation, damit es kompiliert
3. Implementiere registerPolicy
  - dazu musst du die unique_ptr geeignet verwalten
  - testcode nat�rlich wieder einkommentieren
  - vergiss nicht die History aus zu geben
4. Implementiere Write
  - sende formatierte Ausgabe an all Policies
  - vergiss nicht die History zu f�llen (mittels +=)