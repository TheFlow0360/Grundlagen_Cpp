#include "spaceshipfactory.h"

// If spaceships.h would be not included, the SpaceShip's destructor would be unknown.
// This usually leads to a warning
#include "spaceships.h"


// TODO